
export default {
    clicks: '{{count}} click',
    clicks_zero: 'no clicks',
    clicks_other: '{{count}} clicks',
    reset: 'Reset',
  };