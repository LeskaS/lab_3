
export default {
    clicks_zero: 'нет кликов',
    clicks_interval: '(1)[{{count}} клик];(2-4)[{{count}} клика];',
    // "key1_interval": "(1)[one item];(2-7)[a few items];(7-inf)[a lot of items];",
    clicks: '{{count}} кликов',
    reset: 'Сбросить',
  };